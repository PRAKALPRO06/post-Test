package main

import "fmt"

//Muhammad Djoko Susilo
//2311102212
func main(){
	var a, b int

	fmt.Print("Masukan n")
	fmt.Scan(&a)
	fmt.Print("Masukan m")
	fmt.Scan(&b)
	
	for i := 1; i <= b; i++ {
		fmt.Print("%d", a)
		if i != b {
			fmt.Print(" x ")
		}
	}
}