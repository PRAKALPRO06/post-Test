package main

import (
	"fmt"
	"strconv"
)


func cekHadiah(nomorKartu int) string {
	strNumber := strconv.Itoa(nomorKartu)
	
	sama := true
	beda := true
	digitMap := make(map[rune]bool)

	for _, digit := range strNumber {
		if len(digitMap) == 0 {
			digitMap[digit] = true
		} else {
			if _, exists := digitMap[digit]; !exists {
				sama = false
			} else {
				beda = false
			}
			digitMap[digit] = true
		}
	}

	if sama {
		return "Hadiah A"
	}
	if beda {
		return "Hadiah B"
	}
	return "Hadiah C"
}

func main() {
	var n_2311102212 int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scanln(&n_2311102212)

	
	countA, countB, countC := 0, 0, 0

	
	for i := 0; i < n_2311102212; i++ {
		var nomorPeserta int
		fmt.Printf("Masukkan nomor peserta ke-%d: ", i+1)
		fmt.Scanln(&nomorPeserta)

		hadiah := cekHadiah(nomorPeserta)
		fmt.Printf("Peserta ke-%d mendapatkan %s\n", i+1, hadiah)

		switch hadiah {
		case "Hadiah A":
			countA++
		case "Hadiah B":
			countB++
		case "Hadiah C":
			countC++
		}
	}

	fmt.Println("Total peserta yang mendapatkan Hadiah A:", countA)
	fmt.Println("Total peserta yang mendapatkan Hadiah B:", countB)
	fmt.Println("Total peserta yang mendapatkan Hadiah C:", countC)
}