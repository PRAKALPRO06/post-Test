package main

import (
	"fmt"
	"strconv"
)

func main() {
	var a_2311102212, tgh int

	fmt.Print("Masukan bilangan bulat positif >10: ")
	fmt.Scan(&a_2311102212)

	inputStr := strconv.Itoa(a_2311102212)
	length := len(inputStr)


	if length % 2 == 0 {
		tgh = length / 2
	} else {
		tgh = length/2 + 1
	}

	bil1 := inputStr[:tgh]
	bil2 := inputStr[tgh:]

	bil1Int, _:= strconv.Atoi(bil1)
	bil2Int, _:= strconv.Atoi(bil2)

	fmt.Printf("Bilangan1: %s\n", bil1)
	fmt.Printf("Bilangan2: %s\n", bil2)

	fmt.Printf("Hasil: %d", bil1Int + bil2Int)
}