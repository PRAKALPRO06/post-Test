package main

import "fmt"

func jumlahKelipatan4(bilangan326 int, jumlah_Deshan int) int {
	if bilangan326 < 0 {
		return jumlah_Deshan
	}

	if bilangan326%4 == 0 {
		jumlah_Deshan += bilangan326
	}

	return jumlahKelipatan4(bilangan326-1, jumlah_Deshan)
}

func main() {
	var bilangan326, jumlah_Deshan int

	fmt.Println("Masukkan bilangan bulat positif (akhiir dengan bilangan negatif):")

	for {
		fmt.Scan(&bilangan326)
		if bilangan326 < 0 {
			break
		}
	}

	jumlah_Deshan = jumlahKelipatan4(bilangan326+1, 0)

	fmt.Printf("Jumlah bilangan bulat positif kelipatan 4 adalah: %d\n", jumlah_Deshan)
}
