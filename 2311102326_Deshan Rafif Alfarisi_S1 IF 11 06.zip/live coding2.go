package main

import (
	"fmt"
)

func hitungBiayaMakan(jumlahMenu_deshan, jumlahOrang int, adaSisa bool) int {
	var biaya int
	if jumlahMenu_Deshan <= 3 {
		biaya = 10000
	} else if jumlahMenu_Deshan > 50 {
		biaya = 100000
	} else {
		biaya = 10000 + (jumlahMenu_Deshan-3)*2500
	}

	if adaSisa {
		biaya *= jumlahOrang
	}

	return biaya
}

func main() {
	var M int
	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&M)

	for i := 0; i < M; i++ {
		var jumlahMenu_Deshan, jumlahOrang int
		var adaSisa bool

		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan untuk rombongan ke-%d: ", i+1)
		fmt.Scan(&jumlahMenu_Deshan, &jumlahOrang, &adaSisa)

		totalBiaya := hitungBiayaMakan(jumlahMenu_Deshan, jumlahOrang, adaSisa)

		fmt.Printf("Total biaya rombongan ke-%d: Rp %d\n", i+1, totalBiaya)
	}
}
