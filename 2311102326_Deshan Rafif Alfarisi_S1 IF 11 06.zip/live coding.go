package main

import "fmt"

func main() {
	var a326, b_Deshan int

	fmt.Print("Masukkan bilangan ke 1: ")
	fmt.Scan(&a326)
	fmt.Print("Masukkan bilangan ke 2: ")
	fmt.Scan(&b_Deshan)

	if a326 > b_Deshan {
		fmt.Println("Bilangan ke 1 harus <= bilangan ke 2.")
		return
	}

	count := 0
	for i := a326; i <= b_Deshan; i++ {
		if i%2 != 0 {
			count++
		}
	}

	fmt.Printf("Jumlah bilangan ganjil antara %d dan %d adalah: %d\n", a326, b_Deshan, count)
}
