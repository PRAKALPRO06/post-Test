//2311102018
package main
import(
	"fmt"
	"strconv"
	"strings"
)
func main(){
	var n int 
	println("Masukan Jumlah Peserta")
	Scanln(&n)
	var int hadiahA, hadiahB,hadiahC int
	for i:=1;i <=n;i++{
		var nomor string
		println("Masukan Nomor kartu peserta :")
		Scan(&nomor)

		sama:= true
		forJ:=1,[j]!=nomor[j++]
		if nomor[j]!=nomor[j-1]{
			sama =false
			break
			println("Jumlah yang memperoleh Hadiah A")
			println("Jumlah yang memperoleh Hadiah B")
			println("Jumlah yang memperoleh Hadiah C")
		}
	}
}