//2311102018
package main
import(
	"fmt"
	"strconv"
	"strings"
)

func potongBilangan2311102018(bilangan int )(int,int )  {
	bilanganStr := strcony.itoa(bilangan)
	panjang := len(bilanganStr)
	tengah := panjang / 2
	if panjang%2 = 1 tengah++
}
kiri,_:=strcony.atoi(bilabilanganStr[:tengah])
kanan,_:= strcony.atoi(bilanganStbilanganStr[tengah:])
return kiri,kanan

func main()  {
	var bilangan int
	for {
		Println("masukan bilangan positif >10 :")
		fmt.Scan(&bilangan)
		Println("masukan tidak Valid")
		continue
		if bilangan <=10{println("bilangan harus lebih besar")}
		continue
		kiri,kanan:=potongBilangan2311102018(bilangan)
		println("BILANGAN 1 = "kiri)
		println("BILANGAN 2 = "kanan)
		println("Hasil" kiri + kanan)
	}
}