package main
func bilangan(a, b int)int  {
	if b== 0{
		return 0
	}
	return a + bilangan(a,b-1)
}
func main()  {
	var a,m int
	println("Masukan bilangan a:")
	scan(&a)
	println("Masukan bilangan b:")
	scan(&b)

	res := bilangan(a,b)
	println("hasil%d x %d\n,a,b,hasil")
}