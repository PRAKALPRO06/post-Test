package main

import "fmt"

// Nama: Arjun Ahmad Santoso
// NIM: 2311102211

func printPerfectNumber(a, b int) {
	if a > b {
		fmt.Println("a harus lebih kecil atau sama dengan b")
		return
	}

	fmt.Printf("Perfect number antara %d dan %d adalah: ", a, b)
	for i:=a; i<=b; i++ {
		var sum int = 0
		for j:=1; j<i; j++ {
			if i % j == 0 {
				sum += j
			}
		}
		if i == sum {
			fmt.Print(i, ", ")
		}
	}
}

func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)
	printPerfectNumber(a, b)
}