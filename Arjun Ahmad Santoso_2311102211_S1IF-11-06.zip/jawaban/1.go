package main

import "fmt"

// Nama: Arjun Ahmad Santoso
// NIM: 2311102211

func hitungBiaya(jam, menit int, isMember bool) {

	var biaya_per_jam int
	var total_biaya float64
	if isMember {
		biaya_per_jam = 3500
	} else {
		biaya_per_jam = 5000
	}
	total_biaya = (float64(jam) + float64(menit)/60) * float64(biaya_per_jam)
	if jam >= 3 && menit > 0 {
		total_biaya = total_biaya - (total_biaya / 10)
	}
	fmt.Println("Biaya sewa setelah diskon (jika memenuhi syarat) : Rp ", total_biaya, ".00")
}

func main() {
	var jam, menit int
	var isMember bool
	var nomorVoucher_2311102211 int

	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah member? (true/false): ")
	fmt.Scan(&isMember)
	fmt.Print("Masukkan nomer voucher (jika ada): ")
	fmt.Scan(&nomorVoucher_2311102211)

	hitungBiaya(jam, menit, isMember)
}