package main

import "fmt"

// Nama: Arjun Ahmad Santoso
// NIM: 2311102211

func printJumlahPertemuanDalamSetahun(x, y int) {
	var jumlah_hari_dalam_setahun int = 365
	var jumlah_pertemuan_dalam_setahun int = 0
	for i:=0; i<jumlah_hari_dalam_setahun; i++ {
		if i % x == 0 && i % y != 0 {
			jumlah_pertemuan_dalam_setahun++
		}
	}
	fmt.Println("Jumlah pertemuan dalam setahun: ", jumlah_pertemuan_dalam_setahun)
}

func main() {
	var x_2311102211, y int
	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x_2311102211)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y)
	
	printJumlahPertemuanDalamSetahun(x_2311102211, y)
}