// 2311102255
// Bintang Putra Angkasa
package main

import (
	"fmt"
)

func main() {

	var a, b int

	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	if a > b {
		fmt.Println("Nilai a harus kurang dari atau sama dengan b.")
		return
	}

	bilanganSempurna := bintang_rentang(a, b)

	if len(bilanganSempurna) > 0 {
		fmt.Printf("Bilangan sempurna antara %d dan %d: ", a, b)
		for i, num := range bilanganSempurna {
			if i > 0 {
				fmt.Print(", ")
			}
			fmt.Print(num)
		}
		fmt.Println()
	} else {
		fmt.Printf("Tidak ada bilangan sempurna antara %d dan %d.\n", a, b)
	}
}

func cekBilanganSempurna(n int) bool {
	if n <= 1 {
		return false
	}
	sum := 0
	for i := 1; i <= n/2; i++ {
		if n%i == 0 {
			sum += i
		}
	}
	return sum == n
}

func bintang_rentang(a, b int) []int {
	var bilanganSempurna []int
	for num := a; num <= b; num++ {
		if cekBilanganSempurna(num) {
			bilanganSempurna = append(bilanganSempurna, num)
		}
	}
	return bilanganSempurna
}
