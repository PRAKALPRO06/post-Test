// Bintang Putra Angkasa
// 2311102255
package main

import (
	"fmt"
)

func main() {
	var durasiJam, durasiMenit, bintangvoucher int
	var member bool

	fmt.Println("Masukkan lama sewa (jam): ")
	fmt.Scan(&durasiJam)

	fmt.Println("Masukkan lama sewa (menit): ")
	fmt.Scan(&durasiMenit)

	fmt.Println("Apakah Anda member? (true/false): ")
	fmt.Scan(&member)

	fmt.Println("Masukkan nomor voucher (jika ada, masukkan 0 jika tidak ada): ")
	fmt.Scan(&bintangvoucher)

	total := totalsewa(durasiJam, durasiMenit, member)

	durasiTotal := durasiJam + (durasiMenit+59)/60 //

	if durasiTotal > 3 && cekDiskon_2311102255(member, bintangvoucher) {
		total *= 0.90
	}

	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", total)
}

func cekDiskon_2311102255(member bool, bintangvoucher int) bool {
	if member && (bintangvoucher >= 10000 && bintangvoucher <= 999999) {
		return true
	}
	return false
}

func totalsewa(durasiJam, durasiMenit int, member bool) float64 {
	totalMenit := durasiJam*60 + durasiMenit
	if member {
		return float64(totalMenit) / 60 * 3500
	}

	return float64(totalMenit) / 60 * 5000
}
