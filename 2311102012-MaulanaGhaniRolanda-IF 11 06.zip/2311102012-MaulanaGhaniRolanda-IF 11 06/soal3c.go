package main

import (
	"fmt"
)

func Multiply_2311102012(n, m int) int {
	if m == 0 {
		return 0
	}
	return n + Multiply_2311102012(n, m-1)
}

func main() {
	var n, m int
	fmt.Print("Masukan Bilangan n: ")
	fmt.Scan(&n)
	fmt.Print("Masukan Bilangan m: ")
	fmt.Scan(&m)

	result := Multiply_2311102012(n, m)

	fmt.Printf("Hasil dari %d x %d = %d\n", n, m, result)
}
