package main

import (
	"fmt"
	"strconv"
)

func allSameDigits(num_2311102012 int) bool {
	numStr := strconv.Itoa(num_2311102012)
	firstDigit := numStr[0]
	for _, digit := range numStr {
		if byte(digit) != firstDigit {
			return false
		}
	}
	return true
}

func allDifferentDigits(num_2311102012 int) bool {
	numStr := strconv.Itoa(num_2311102012)
	digitMap := make(map[rune]bool)

	for _, digit := range numStr {
		if digitMap[digit] {
			return false
		}
		digitMap[digit] = true
	}
	return true
}

func main() {
	var N int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&N)

	countA, countB, countC := 0, 0, 0

	for i := 1; i <= N; i++ {
		var cardNumber int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scan(&cardNumber)

		if allSameDigits(cardNumber) {
			fmt.Println("Hadiah A")
			countA++
		} else if allDifferentDigits(cardNumber) {
			fmt.Println("Hadiah B")
			countB++
		} else {
			fmt.Println("Hadiah C")
		}
	}

	fmt.Printf("Jumlah yang memperoleh Hadiah A: %d\n", countA)
	fmt.Printf("Jumlah yang memperoleh Hadiah B: %d\n", countB)
	fmt.Printf("Jumlah yang memperoleh Hadiah C: %d\n", countC)
}
