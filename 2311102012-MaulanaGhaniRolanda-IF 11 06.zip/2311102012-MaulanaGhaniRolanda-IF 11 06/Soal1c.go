package main

import (
	"fmt"
	"strconv"
)

func splitandAdd(Number_2311102012 int) {
	numberStr := strconv.Itoa(Number_2311102012)
	length := len(numberStr)

	mid := (length + 1) / 2

	leftpart, _ := strconv.Atoi(numberStr[:mid])
	rightpart, _ := strconv.Atoi(numberStr[mid:])

	sum := leftpart + rightpart

	fmt.Printf("bilangan 1: %d\n", leftpart)
	fmt.Printf("bilangan 2: %d\n", rightpart)
	fmt.Printf("Hasil penjumlahan: %d\n", sum)
}

func main() {
	var Number_2311102012 int
	fmt.Print("Masukkan bilangan bulat: ")
	fmt.Scan(&Number_2311102012)

	splitandAdd(Number_2311102012)
}
