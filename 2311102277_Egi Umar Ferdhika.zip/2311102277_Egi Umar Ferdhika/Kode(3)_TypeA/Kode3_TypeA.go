package main

import (
	"fmt"
)

// nim_2311102277 sebagai variabel x
func hitung_pertemuan(nim_2311102277 int, y int) int {
	hitung := 0
	for hari := 1; hari <= 365; hari++ {
		if hari%nim_2311102277 == 0 && hari%y != 0 {
			hitung++
		}
	}
	return hitung
}

func main() {
	var nim_2311102277, y int
	fmt.Print("Masukkan nilai x (kelipatan): ")
	fmt.Scan(&nim_2311102277)
	fmt.Print("Masukkan nilai y (bukan kelipatan): ")
	fmt.Scan(&y)

	pertemuan := hitung_pertemuan(nim_2311102277, y)
	fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", pertemuan)
}
