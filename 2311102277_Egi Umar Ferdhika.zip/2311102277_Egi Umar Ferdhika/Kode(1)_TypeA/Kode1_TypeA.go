package main

import (
	"fmt"
)

func HitungDurasi(durasi_sewaJam, durasi_sewaMenit int) int {
	return durasi_sewaJam*60 + durasi_sewaMenit
}

func HitungBiaya(durasi_sewaJam, durasi_sewaMenit int, nim_2311102277 bool) int {
	var biayaPerJam int
	// nim_2311102277 disini sebagai variabel member
	if nim_2311102277 {
		biayaPerJam = 3500
	} else {
		biayaPerJam = 5000
	}
	return biayaPerJam*durasi_sewaJam + (biayaPerJam/60)*durasi_sewaMenit
}

func HitungDiskon(biaya int, durasi_sewaJam int) int {
	if durasi_sewaJam >= 3 {
		return biaya * 10 / 100
	}
	return 0
}

func isMember(nim_2311102277 bool) bool {
	return nim_2311102277
}

func main() {
	var durasi int
	var durasi_sewaJam, durasi_sewaMenit int
	var nim_2311102277 bool

	fmt.Print("Masukkan durasi sewa (jam): ")
	fmt.Scan(&durasi_sewaJam)
	fmt.Print("Masukkan durasi sewa (menit): ")
	fmt.Scan(&durasi_sewaMenit)

	var StatusMember string
	fmt.Print("Apakah Anda member? (ya/tidak): ")
	fmt.Scan(&StatusMember)
	nim_2311102277 = (StatusMember == "ya")

	durasi = HitungDurasi(durasi_sewaJam, durasi_sewaMenit)

	membership := isMember(nim_2311102277)

	biaya := HitungBiaya(durasi_sewaJam, durasi_sewaMenit, nim_2311102277)

	diskon := HitungDiskon(biaya, durasi_sewaJam)

	totalBiaya := biaya - diskon

	fmt.Printf("Durasi sewa: %d jam %d menit\n", durasi_sewaJam, durasi_sewaMenit)
	fmt.Printf("Total durasi sewa dalam menit: %d menit\n", durasi)
	fmt.Printf("Anda berstatus Member: %t\n", membership)
	fmt.Printf("Biaya sewa sebelum diskon: Rp %d\n", biaya)
	if diskon > 0 {
		fmt.Printf("Diskon: Rp %d\n", diskon)
	}
	fmt.Printf("Biaya sewa setelah diskon: Rp %d\n", totalBiaya)
}
