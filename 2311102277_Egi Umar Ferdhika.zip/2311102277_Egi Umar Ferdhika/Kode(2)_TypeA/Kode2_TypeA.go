package main

import (
	"fmt"
)

func Perfect_number(n int) bool {
	if n < 2 {
		return false
	}
	nim_2311102277 := 1
	for i := 2; i <= n/2; i++ {
		if n%i == 0 {
			nim_2311102277 += i
		}
	}
	return nim_2311102277 == n
}
func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	fmt.Printf("Perfect Number diantara rentang  %d dan %d adalah :\n", a, b)

	for i := a; i <= b; i++ {
		if Perfect_number(i) {
			fmt.Println(i)
		}
	}
}
