//2311102186_Bhara Yudha Pamungkas
package main
import (
        "fmt"
)
func main() {
        var jumlahRombongan int
        fmt.Print("Masukkan jumlah rombongan: ")
        fmt.Scan(&jumlahRombongan)
        for i := 1; i <= jumlahRombongan; i++ {
                var jumlahMenu, jumlahOrang int
                var adaSisa bool
                fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) untuk rombongan %d: ", i)
                fmt.Scan(&jumlahMenu, &jumlahOrang, &adaSisa)
                hargaPerMenu := 2311102186
                totalBiaya := jumlahMenu * jumlahOrang * hargaPerMenu
                if adaSisa {
                        totalBiaya += int(float64(totalBiaya) * 0.1)
                }
                fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, totalBiaya)
        }
}