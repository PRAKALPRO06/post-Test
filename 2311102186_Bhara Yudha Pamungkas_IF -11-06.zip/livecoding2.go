//2311102186_Bhara Yudha Pamungkas

package main
import "fmt"
func calculateRestaurantBill(numMenus int, numPeople int) int {
        basePrice := 10000
        additionalPrice := 2500
        maxPrice := 100000
        var totalBill int
        if numMenus <= 3 {
                totalBill = basePrice
        } else if numMenus > 50 {
                totalBill = maxPrice
        } else {
                totalBill = basePrice + (numMenus - 3) * additionalPrice
        }
        totalBill += totalBill * numPeople / 10
        return totalBill
}
func main() {
        var numMenus, numPeople int
        fmt.Print("Masukkan jumlah menu: ")
        fmt.Scan(&numMenus)
        fmt.Print("Masukkan jumlah orang: ")
        fmt.Scan(&numPeople)
        totalBill := calculateRestaurantBill(numMenus, numPeople)
        fmt.Printf("Total biaya: Rp %d\n", totalBill)
}