//2311102186_ Bhara Yudha Pamungkas

package main
import "fmt"
func sumMultiplesOf4Iterative(numbers []int) int {
        sum := 0
        for _, num := range numbers {
                if num <= 0 {
                        break
                }
                if num%4 == 0 {
                        sum += num
                }
        }
        return sum
}
func sumMultiplesOf4Recursive(numbers []int, index int, sum int) int {
        if index >= len(numbers) || numbers[index] <= 0 {
                return sum
        }

        if numbers[index]%4 == 0 {
                sum += numbers[index]
        }

        return sumMultiplesOf4Recursive(numbers, index+1, sum)
}
func main() {
        var numbers []int
        var num int
        fmt.Println("Masukkan bilangan (negatif untuk berhenti):")
        for {
                fmt.Scan(&num)
                if num <= 0 {
                        break
                }
                numbers = append(numbers, num)
        }
        iterativeSum := sumMultiplesOf4Iterative(numbers)
        fmt.Printf("Jumlah bilangan kelipatan 4 (iteratif): %d\n", iterativeSum)
        recursiveSum := sumMultiplesOf4Recursive(numbers, 0, 0)
        fmt.Printf("Jumlah bilangan kelipatan 4 (rekursif): %d\n", recursiveSum)
}