package main

import (
	"fmt"
	"strconv"
)

func main() {
	var n int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scanln(&n)

	var hadiahA, hadiahB, hadiahC int
	for i := 1; i <= n; i++ {
		var nomorKartu int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scanln(&nomorKartu)

		if isAllDigitsSame(nomorKartu) {
			fmt.Println("Hadiah A")
			hadiahA++
		} else if isAllDigitsDifferent(nomorKartu) {
			fmt.Println("Hadiah B")
			hadiahB++
		} else {
			fmt.Println("Hadiah C")
			hadiahC++
		}
	}

	fmt.Println("\nJumlah peserta yang memperoleh masing-masing hadiah:")
	fmt.Printf("Hadiah A: %d\n", hadiahA)
	fmt.Printf("Hadiah B: %d\n", hadiahB)
	fmt.Printf("Hadiah C: %d\n", hadiahC)
}

func isAllDigitsSame(number int) bool {
	str := strconv.Itoa(number)
	for i := 1; i < len(str); i++ {
		if str[i] != str[0] {
			return false
		}
	}
	return true
}

func isAllDigitsDifferent(number int) bool {
	str := strconv.Itoa(number)
	for i := 0; i < len(str)-1; i++ {
		for j := i + 1; j < len(str); j++ {
			if str[i] == str[j] {
				return false
			}
		}
	}
	return true
}