package main

import "fmt"

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scanln(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scanln(&m)
	fmt.Println("Hasil dari", n, "x", m, "=", multiply(n, m))
}

func multiply(n, m int) int {
	if m == 0 {
		return 0
	}
	return n + multiply(n, m-1)
}
