//Martin Simbolon
//2311102269

package main

import (
	"fmt"
	"strconv"
)

func main() {
	var input int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&input)

	if input <= 10 {
		fmt.Println("Bilangan harus lebih besar dari 10")
		return
	}

	length := len(strconv.Itoa(input))
	mid := length / 2

	var left, right string
	if length%2 == 0 {
		
		left = strconv.Itoa(input)[:mid]
		right = strconv.Itoa(input)[mid:]
	} else {
		
		left = strconv.Itoa(input)[:mid+1]
		right = strconv.Itoa(input)[mid+1:]
	}

	leftInt, _ := strconv.Atoi(left)
	rightInt, _ := strconv.Atoi(right)

	fmt.Println("Bilangan 1:", leftInt)
	fmt.Println("Bilangan 2:", rightInt)
	fmt.Println("Hasil penjumlahan:", leftInt+rightInt)
}
