//2311102253_Muhammad Djulianoor

package main

import "fmt"

func main() {
	var a_2311102253, b int

	fmt.Println("Syarat: a <= b")
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a_2311102253)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	perfect_number(a_2311102253, b)
}

func perfect_number(a, b int) {
	if a <= b {
		result := a + b
		fmt.Print(a, "+", b, "=")
		fmt.Print(result)
	} else {
		fmt.Print("Syarat tidak terpenuhi!")
	}
}
