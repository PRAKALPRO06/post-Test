//2311102253_Muhammad Djulianoor

package main

import "fmt"

func main() {
	var durasi_jam_2311102253, durasi_menit, voucher float32
	var member_status string

	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&durasi_jam_2311102253)
	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&durasi_menit)
	fmt.Print("Apakah member? (true/false): ")
	fmt.Scan(&member_status)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&voucher)

	input(durasi_jam_2311102253, durasi_menit, voucher, member_status)
}

func input(durasi_jam_2311102253, durasi_menit, voucher float32, member_status string) {
	var result float32
	var result2 float32
	var harga1_jam float32
	var harga1_jam_non float32
	harga1_jam_non = 5000
	harga1_jam = 3500

	if durasi_jam_2311102253 == 1 && durasi_menit <= 59 && member_status == "true" || member_status == "True" && voucher == 0 {
		result = durasi_jam_2311102253 * harga1_jam
		fmt.Print(result)
	} else if durasi_jam_2311102253 == 2 && durasi_menit <= 59 && member_status == "true" || member_status == "True" && voucher == 0 {
		result = durasi_jam_2311102253 * harga1_jam
		fmt.Print(result)
	} else if durasi_jam_2311102253 == 3 && durasi_menit <= 59 && member_status == "true" || member_status == "True" && voucher == 0 {
		result = durasi_jam_2311102253 * harga1_jam
		fmt.Print(result)
	} else if durasi_jam_2311102253 >= 3 && durasi_menit <= 59 && member_status == "true" || member_status == "True" || voucher == 123456 {
		result = (durasi_jam_2311102253 * harga1_jam) * 0.1
		result2 = durasi_jam_2311102253*harga1_jam - result
		fmt.Print(result2)
	} else if durasi_jam_2311102253 == 1 && durasi_menit <= 59 && member_status == "false" || member_status == "false" && voucher == 0 {
		result = durasi_jam_2311102253 * harga1_jam_non
		fmt.Print(result)
	} else if durasi_jam_2311102253 == 2 && durasi_menit <= 59 && member_status == "false" || member_status == "False" && voucher == 0 {
		result = durasi_jam_2311102253 * harga1_jam_non
		fmt.Print(result)
	} else if durasi_jam_2311102253 >= 3 && durasi_menit <= 59 && member_status == "false" || member_status == "False" || voucher == 123456 {
		result = (durasi_jam_2311102253 * harga1_jam_non) * 0.1
		result2 = durasi_jam_2311102253*harga1_jam_non - result
		fmt.Print(result2)
	} else {
		fmt.Print("Invalid")
	}
}
