//2311102253_Muhammad Djulianoor

package main

import "fmt"

func main() {
	var a, b int

	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&b)

	pertemuan(a, b)
}

func pertemuan(x, y int) {
	satu_tahun_2311102253 := 365

	result := x * satu_tahun_2311102253 / y

	fmt.Print("Jumlah pertemuan dalam setahun: ", result)
}
