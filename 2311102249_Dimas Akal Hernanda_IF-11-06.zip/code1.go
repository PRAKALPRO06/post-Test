// Dimas Akal Hernanda_2311102249
package main

import (
	"fmt"
)

const (
	memberRate    = 3500
	nonMemberRate = 5000
)

func computeRentalDuration(hours int, minutes int) int {
	if hours < 1 && minutes < 10 {
		return 0
	}
	if minutes >= 10 {
		hours++
	}
	return hours
}

func computeTotalCost(hours int, isMember bool) float64 {
	rate := memberRate
	if !isMember {
		rate = nonMemberRate
	}
	return float64(hours * rate)
}

func applyPromoDiscount(totalCost float64, promoCode string) float64 {
	if len(promoCode) == 5 || len(promoCode) == 6 {
		return totalCost * 0.9
	}
	return totalCost
}

func main() {
	var rentalHours, rentalMinutes int
	var isMember bool
	var promoCode string

	fmt.Print("Enter rental duration (hours): ")
	fmt.Scan(&rentalHours)
	fmt.Print("Enter rental duration (minutes): ")
	fmt.Scan(&rentalMinutes)
	fmt.Print("Are you a member? (true/false): ")
	fmt.Scan(&isMember)

	totalRentalHours := computeRentalDuration(rentalHours, rentalMinutes)
	if totalRentalHours < 3 {
		fmt.Println("Rental duration must be at least 3 hours.")
		return
	}

	totalCost := computeTotalCost(totalRentalHours, isMember)

	fmt.Print("Enter promo code: ")
	fmt.Scan(&promoCode)

	finalAmount := applyPromoDiscount(totalCost, promoCode)

	fmt.Printf("Rental cost after discount: Rp %.2f\n", finalAmount)
}
