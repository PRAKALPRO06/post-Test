// Dimas Akal Hernanda_2311102249
package main

import (
	"fmt"
)

func main() {
	var x, y int

	fmt.Print("Masukkan nilai x : ")
	fmt.Scan(&x)
	fmt.Print("Masukkan nilai y : ")
	fmt.Scan(&y)

	jumlahPertemuan := hitungPertemuan(x, y)

	fmt.Printf("Jumlah hari pertemuan rahasia dalam setahun: %d\n", jumlahPertemuan)
}

func hitungPertemuan(x int, y int) int {
	jumlahHari := 0
	totalHari := 365

	for hari := 1; hari <= totalHari; hari++ {
		if hari%x == 0 && hari%y != 0 {
			jumlahHari++
		}
	}

	return jumlahHari
}
