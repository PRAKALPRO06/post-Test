//	Nama	: Rendi Widya Anggita
//	NIM		: 2311102278

package main

import (
	"fmt"
)

func tentukanHadiah(nomorKartu_2311102278 int) string {
	var set [10]bool

	for nomorKartu_2311102278 > 0 {
		digit := nomorKartu_2311102278 % 10
		if set[digit] {
			return "Hadiah C"
		}
		set[digit] = true
		nomorKartu_2311102278 /= 10
	}

	return "Hadiah A"
}

func analisisHadiah(nomorKartu_2311102278 int) (string, int) {
	hadiah := tentukanHadiah(nomorKartu_2311102278)
	if hadiah == "Hadiah A" {
		return hadiah, 1
	}

	digitPertama := -1
	for nomorKartu_2311102278 > 0 {
		digit := nomorKartu_2311102278 % 10
		if digitPertama == -1 {
			digitPertama = digit
		} else if digitPertama != digit {
			return "Hadiah B", 1
		}
		nomorKartu_2311102278 /= 10
	}

	return hadiah, 1
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&n)

	hadiahA, hadiahB, hadiahC := 0, 0, 0

	for i := 0; i < n; i++ {
		var nomorKartu_2311102278 int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i+1)
		fmt.Scan(&nomorKartu_2311102278)

		hadiah, count := analisisHadiah(nomorKartu_2311102278)
		if hadiah == "Hadiah A" {
			hadiahA += count
		} else if hadiah == "Hadiah B" {
			hadiahB += count
		} else if hadiah == "Hadiah C" {
			hadiahC += count
		}
		fmt.Println(hadiah)
	}

	fmt.Println("Hadiah A:", hadiahA)
	fmt.Println("Hadiah B:", hadiahB)
	fmt.Println("Hadiah C:", hadiahC)
}