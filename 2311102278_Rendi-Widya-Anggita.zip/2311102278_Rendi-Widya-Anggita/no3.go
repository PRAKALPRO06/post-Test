//	Nama	: Rendi Widya Anggita
//	NIM		: 2311102278

package main

import (
	"fmt"
)

func perkalian(n_2311102278, m int) int {
	result := 0
	for i := 0; i < n_2311102278; i++ {
		result += m
	}
	return result
}

func main() {
	var n_2311102278, m int

	fmt.Print("Masukkan bilangan n: ")
	fmt.Scan(&n_2311102278)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scan(&m)

	hasil := perkalian(n_2311102278, m)

	fmt.Print("Hasil perkaliannya adalah : ", hasil)
}