//	Nama	: Rendi Widya Anggita
//	NIM		: 2311102278

package main

import (
	"fmt"
)

func potongBilangan(n_2311102278 int) (int, int) {
	hitungdigit := 0
	bilawal := n_2311102278

	for n_2311102278 > 0 {
		hitungdigit++
		n_2311102278 /= 10
	}

	mid := (hitungdigit + 1) / 2
	misal := 1

	for i := 0; i < hitungdigit-mid; i++ {
		misal *= 10
	}

	awal := bilawal / misal
	akhir := bilawal % misal

	return awal, akhir
}

func main() {
	var input int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&input)

	if input <= 10 {
		fmt.Println("Bilangan harus lebih besar dari 10")
		return
	}

	bil1, bil2 := potongBilangan(input)

	fmt.Println("Bilangan 1:", bil1)
	fmt.Println("Bilangan 2:", bil2)
	fmt.Println("Hasil penjumlahan:", bil1+bil2)
}