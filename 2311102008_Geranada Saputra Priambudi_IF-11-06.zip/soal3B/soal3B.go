package main

// Geranada Saputra Priambudi 2311102008
import (
	"fmt"
)

func hitungKelipatan4_2311102008(data []int, pos int, total int) int {
	if pos >= len(data) {
		return total
	}

	if data[pos] > 0 && data[pos]%4 == 0 {
		total += data[pos]
	}

	return hitungKelipatan4_2311102008(data, pos+1, total)
}

func main() {
	var angka []int
	var nilai int

	fmt.Println("Masukkan bilangan (negatif untuk berhenti):")
	for {
		fmt.Scan(&nilai)
		if nilai < 0 {
			break
		}
		angka = append(angka, nilai)
	}

	jumlah := hitungKelipatan4_2311102008(angka, 0, 0)

	fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", jumlah)
}