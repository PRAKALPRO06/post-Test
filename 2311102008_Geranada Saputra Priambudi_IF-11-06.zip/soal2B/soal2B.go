package main

// Geranada Saputra Priambudi 2311102008

import (
	"fmt"
)

func main() {
	var M_2311102008 int

	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&M_2311102008)

	for i := 1; i <= M_2311102008; i++ {
		var jumlahMenu, jumlahOrang, sisa int
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) : ")
		fmt.Scan(&jumlahMenu, &jumlahOrang, &sisa)

		var totalBiaya int
		if jumlahMenu > 50 {
			totalBiaya = 100000
		} else if jumlahMenu <= 3 {
			totalBiaya = 10000
		} else {
			totalBiaya = 10000 + (jumlahMenu-3)*2500
		}

		if sisa == 1 {
			totalBiaya *= jumlahOrang
		}

		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, totalBiaya)
	}
}