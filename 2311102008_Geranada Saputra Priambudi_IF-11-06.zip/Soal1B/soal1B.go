package main

// Geranada Saputra Priambudi 2311102008
import (
	"fmt"
)

func main() {
	var a_2311102008, b_2311102008 int

	fmt.Print("Masukkan nilai a_2311102008: ")
	fmt.Scan(&a_2311102008)
	fmt.Print("Masukkan nilai b_2311102008: ")
	fmt.Scan(&b_2311102008)

	if a_2311102008 <= 0 || b_2311102008 <= 0 || a_2311102008 > b_2311102008 {
		fmt.Println("Input tidak valid. Pastikan a_2311102008 dan b_2311102008 adalah bilangan bulat positif dan a_2311102008 <= b_2311102008.")
		return
	}

	count := 0

	for i := a_2311102008; i <= b_2311102008; i++ {
		if i%2 != 0 {
			count++
		}
	}
	fmt.Printf("Banyaknya angka ganjil: %d\n", count)
}