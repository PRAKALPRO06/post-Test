//2311102037 BRIAN FARREL EVANDHIKA IF 11 06
package main
import "fmt"

func main()  {
	var a2311102037, b int

	fmt.Print("Masukan Angka A : ")
	fmt.Scanln(&a2311102037)
	fmt.Print("Masukan Angka B :")\
	fmt.Scanln(&b)

	if a2311102037 <= 0 {
		fmt.Println("Kodingan Error")
	}

	if b <= 0 {
		fmt.Print("Kodingan Error")
	}

	jumlahpertemuan := 0
	for hari := 1; hari <= 365; hari++{
		if hari%a2311102037 == 0 && hari%b != 0 {
			jumlahpertemuan++
		}
	}

	fmt.Printf("Jumlah dari pertemuan dalam setahun : %d\n", jumlahpertemuan)
}