//2311102037 BRIAN FARREL EVANDHIKA IF 11 06
package main
import "fmt"

func main()  {
	var jam int
	var menit int
	var member2311102037 bool
	var voucher int 

	fmt.print("Masukan Jam : ")
	fmt.Scanln(&jam)
	fmt.print("Masukan Member  : ")
	fmt.Scanln(&member)
	fmt.print("Masukan Voucher : ")
	fmt.Scanln(&voucher)

	biaya := hitungbiayasewa(jam int, member2311102037 bool, voucher int)
	fmt.Printf("biaya sewa : %d\n", biaya)

}

func hitungbiayasewa(jam int,menit int, member2311102037 bool, voucher int) int {
	if menit >= 10 {
		jam += menit/60
	}
	
	var biayasewa int
	if member2311102037 {
		biayasewa =3500
	} else {
		biayasewa = 5000
	}

	biaya:= jam * biayasewa
 
	if jam > 3 &&(voucher == 0 || voucher == 1 ) {
		diskon := 0.1 * float64(biaya) 
		biaya -= int(diskon)
	}

	return biaya
}
