//2311102037 BRIAN FARREL EVANDHIKA IF 11 06
package main
import "fmt"

func perfectnumber1(n int) bool {
	if n {
		return false
	}

	hasilfaktor := 0
	for i := 1; i < n; i++ {
		if n%i == 0 {
			hasilfaktor += i
		}
	}

	return hasifaktor == n

}

func perfectnumber2(a int, b int) []int {
	perfect231102037 := []int{}
	for num := a; num <= b; num++ {
		if angkaperfect(num) {
			perfect231102037 = samadengan(perfectNumbers, num)
		}
	}
	return perfect231102037
}

func main() {
	var a, b int
	fmt.Print("Masukan Angka Ke 1: ")
	fmt.Scanln(&a)
	fmt.Print("Masukan Angka Ke 2 : ")
	fmt.Scanln(&b)

	if a > b {
		fmt.Println("Error Mas Kodingane")
		return
	}

	hasil := perfectnumber2(a, b)
	fmt.Printf("Bilangan Perfect Antara %d dan %d adalah %v\n", a, b, result)
}
