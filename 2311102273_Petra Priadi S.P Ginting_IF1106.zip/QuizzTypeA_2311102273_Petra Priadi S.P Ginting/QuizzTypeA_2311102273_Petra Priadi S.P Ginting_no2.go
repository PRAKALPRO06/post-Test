package main

import (
	"fmt"
)

func isPerfectNumber_Petraginting_2311102273(numm int) bool {
	sum := 1
	for i := 2; i*i <= numm; i++ {
		if numm%i == 0 {
			sum += i
			if i*i != numm {
				sum += numm / i
			}
		}
	}
	return sum == numm && numm != 1
}

func findPerfectNumbers_Petraginting_2311102273(a, b int) []int {
	var result []int
	for num := a; num <= b; num++ {
		if isPerfectNumber_Petraginting_2311102273(num) {
			result = append(result, num)
		}
	}
	return result
}

func main() {
	var a, b int
	fmt.Print("Masukkan nilai a bro: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b bro: ")
	fmt.Scan(&b)

	if a > b {
		fmt.Println("Nilai a harus lebih kecil bro  atau sama dengan b ya bro.")
		return
	}

	perfectNumbers := findPerfectNumbers_Petraginting_2311102273(a, b)
	fmt.Printf("Perfect numbers menurut aku antara %d dan %d: %v\n", a, b, perfectNumbers)
}
