package main

import (
	"fmt"
	"math"
	"strings"
)

func hitungBiayaSewaPetraginting_2311102273(jamSewa, menitSewa int, apMember bool, nmrVoucher string) float64 {
	durasiSewa := float64(jamSewa) + float64(menitSewa)/60
	tarifPerJam := 5000.0
	if apMember {
		tarifPerJam = 3500.0
	}
	biayaSewa := durasiSewa * tarifPerJam
	if len(nmrVoucher) > 0 && (len(nmrVoucher) == 5 || len(nmrVoucher) == 6) {
		biayaSewa *= 0.9
	}
	return math.Ceil(biayaSewa)
}

func formatRupiah(amount float64) string {
	return fmt.Sprintf("%d", int(amount))
}

func main() {
	var jamSewa, menitSewa int
	var apMember bool
	var nmrVoucher string

	fmt.Print("Masukkan durasi jam sewa: ")
	fmt.Scan(&jamSewa)

	fmt.Print("Masukkan durasi menit sewa: ")
	fmt.Scan(&menitSewa)

	var mmbrStatus string
	fmt.Print("Apakah punya member? : ")
	fmt.Scan(&mmbrStatus)
	apMember = strings.ToLower(mmbrStatus) == "ya"

	fmt.Print("Masukkan nomor voucher kalau ada : ")
	fmt.Scanln(&nmrVoucher)

	biayaSewa := hitungBiayaSewaPetraginting_2311102273(jamSewa, menitSewa, apMember, nmrVoucher)
	biayaSewaStr := formatRupiah(biayaSewa)

	fmt.Printf("Biaya sewa setelah diskon adalah: Rp %s.00\n", biayaSewaStr)
}
