package main

import (
	"fmt"
)

func hitungPertemuanRahasia_PetraGinting_2311102273(x, y int) int {
	jmlhPertemuan := 0
	for hari := 1; hari <= 365; hari++ {
		if hari%x == 0 && hari%y != 0 {
			jmlhPertemuan++
		}
	}
	return jmlhPertemuan
}

func main() {
	var x, y int

	fmt.Print("Masukkan nilai x bro: ")
	fmt.Scan(&x)

	fmt.Print("Masukkan nilai y bro: ")
	fmt.Scan(&y)

	if x <= 0 || y <= 0 {
		fmt.Println("Error kali bro : x dan y nya bro harus bilangan bulat positif ya bro.")
		return
	}

	jmlhPertemuan := hitungPertemuanRahasia_PetraGinting_2311102273(x, y)
	fmt.Printf("Jumlah pertemuan dalam 1 tahun: %d\n", jmlhPertemuan)
}
