//nama :didik setiawan
//kelas : if 11 a
// nim : if-11-a

package main

import "fmt"

func main() {
	var angka_a2311102030, angka_b2311102030, angkatotal2311102030 float64
	fmt.Print("Masukkan bilangan a ")
	fmt.Scan(&angka_a2311102030)
	fmt.Print("Masukkan bilangan b ")
	fmt.Scan(&angka_b2311102030)

	angkatotal2311102030 = angka_a2311102030 + angka_b2311102030

	if angkatotal2311102030 > 0 {
		bagiangka2311102030 := angkatotal2311102030 / 2
		fmt.Printf("pembagian: %.2f\n", bagiangka2311102030)
	} else {
		fmt.Println("Bilangan harus positif.")
	}
}
