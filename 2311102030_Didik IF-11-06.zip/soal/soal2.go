package main

import "fmt"

func main() {
	fmt.printf("berapa jumlah peseta")
	fmt.printf("masukan kartu peserta")

	fmt.Println("Hello, World!")
}
