//nama :didik setiawan
//kelas : if 11 a
// nim : if-11-a

package main

import "fmt"




func perkalian(n,m int)  {
	result := 0
	for i := 0; i < m; i++ {
		result :+ a
	}	
}

func main() {

	n= 5
	m =6

	fmt.printf("hasil perkalian dari 5 dan 6 adalah" n,m,perkalian(n,m))
	
}

