package main

import "fmt"

func jumlahKelipatan4Rekursif(angka int) int {
        if angka <= 0 {
                return 0
        } else if angka%4 == 0 {
                return angka + jumlahKelipatan4Rekursif(angka-4)
        } else {
                return jumlahKelipatan4Rekursif(angka-1)
        }
}

func main() {
        var nim, angka int
        var jumlah int

        fmt.Print("Masukkan NIM: ")
        fmt.Scan(&nim)

        fmt.Println("Masukkan bilangan (negatif untuk berhenti):")

        for {
                fmt.Scan(&angka)
                if angka <= 0 {
                        break
                }
                jumlah += jumlahKelipatan4Rekursif(angka)
        }

        fmt.Printf("NIM: %d\n", nim)
        fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", jumlah)
}