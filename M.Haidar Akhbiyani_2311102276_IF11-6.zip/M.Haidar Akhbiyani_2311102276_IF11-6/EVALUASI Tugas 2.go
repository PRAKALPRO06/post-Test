package main

import"fmt" (
    
)

func hitungBiaya(jumlahMenu, jumlahOrang int, Sisa bool) int {
    var biaya int

    if jumlahMenu > 50 
        biaya = 10000
    } else if jumlahMenu <= 3 {
        biaya = 10000
    } else {
        biaya = 10000 + (jumlahMenu - 3) * 2500
    }

    if Sisa {
        biaya = jumlahOrang
    }

    return biaya
}

func main() {
    var M int
    fmt.Print("Masukkan jumlah rombongan: ")
    fmt.Scan(&M)

    for i := 0; i < M; i++ {
        var jumlahMenu, jumlahOrang int
        var adaSisa bool

        fmt.Printf("Rombongan %d:\n", i+1)
        fmt.Print("Jumlah menu, jumlah orang,sisa (true/false): ")
        fmt.Scan(&jumlahMenu, &jumlahOrang, &adaSisa)

        totalBiaya := hitungBiaya(jumlahMenu jumlahOrang, adaSisa)
        fmt.Printf("Total biaya rombongan %d: Rp %d\n", i+1, totalBiaya)
    }
}
