package main

import "fmt"

func main() {
        var a, b, nim int
        var jumlahGanjil int

        fmt.Print("Masukkan NIM: ")
        fmt.Scan(&nim)

        fmt.Print("Masukkan nilai a: ")
        fmt.Scan(&a)

        fmt.Print("Masukkan nilai b: ")
        fmt.Scan(&b)

        jumlahGanjil = (b - a + 1) / 2
        if a%2 == 1 && b%2 == 1 {
                jumlahGanjil++
        }

        fmt.Printf("NIM: %d\n", nim)
        fmt.Printf("Banyaknya angka ganjil dari %d hingga %d adalah: %d\n", a, b, jumlahGanjil)
}