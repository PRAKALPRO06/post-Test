package main

import (
	"fmt"
)

// Fariz Ilham
// 2311102275
// IF-11-06
func sewa(Jam, Menit int) int {
	return Jam*60 + Menit
}

func Biaya(Jam, Menit int, waktu_2311102275 bool) int {
	var biayaPerJam int
	if waktu_2311102275 {
		biayaPerJam = 3500
	} else {
		biayaPerJam = 5000
	}
	return biayaPerJam*Jam + (biayaPerJam/60)*Menit
}

func Diskon(biaya int, Jam int) int {
	if Jam >= 3 {
		return biaya * 10 / 100
	}
	return 0
}

func isMember(waktu_2311102275 bool) bool {
	return waktu_2311102275
}

func main() {
	var durasi int
	var Jam, Menit int
	var waktu_2311102275 bool

	fmt.Print("Masukkan durasi sewa (jam): ")
	fmt.Scan(&Jam)
	fmt.Print("Masukkan durasi sewa (menit): ")
	fmt.Scan(&Menit)

	var StatusMember string
	fmt.Print("Apakah Anda member? (ya/tidak): ")
	fmt.Scan(&StatusMember)
	waktu_2311102275 = (StatusMember == "ya")

	durasi = sewa(Jam, Menit)

	membership := isMember(waktu_2311102275)

	biaya := Biaya(Jam, Menit, waktu_2311102275)

	diskon := Diskon(biaya, Jam)

	totalBiaya := biaya - diskon

	fmt.Printf("Durasi sewa: %d jam %d menit\n", Jam, Menit)
	fmt.Printf("Total durasi sewa dalam menit: %d menit\n", durasi)
	fmt.Printf("Anda berstatus Member: %t\n", membership)
	fmt.Printf("Biaya sewa sebelum diskon: Rp %d\n", biaya)
	if diskon > 0 {
		fmt.Printf("Diskon: Rp %d\n", diskon)
	}
	fmt.Printf("Biaya sewa setelah diskon: Rp %d\n", totalBiaya)
}
