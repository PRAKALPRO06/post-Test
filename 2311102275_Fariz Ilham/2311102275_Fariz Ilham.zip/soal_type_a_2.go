package main

import (
	"fmt"
)

// Fariz Ilham
// 2311102275
// IF-11-06
func isPerfect_2311102275(num int) bool {
	sum := 0
	for i := 1; i < num; i++ {
		if num%i == 0 {
			sum += i
		}
	}
	return sum == num
}

func perfectNumbers(a, b int) {
	fmt.Printf("Perfect numbers antara %d dan %d: ", a, b)
	for i := a; i <= b; i++ {
		if isPerfect_2311102275(i) {
			fmt.Printf("%d ", i)
		}
	}
	fmt.Println()
}

func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	if a > b {
		fmt.Println("Eror")
		return
	}

	perfectNumbers(a, b)
}
