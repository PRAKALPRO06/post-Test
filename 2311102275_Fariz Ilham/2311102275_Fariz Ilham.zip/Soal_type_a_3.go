package main

import (
	"fmt"
)

// Fariz Ilham
// 2311102275
// IF-11-06
func pertemuan_2311102275(x, y int) int {
	tahun := 0
	for hari := 1; hari <= 365; hari++ {
		if hari%x == 0 && hari%y != 0 {
			tahun++
		}
	}
	return tahun
}

func main() {
	var x, y int
	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y)

	if x <= 0 || y <= 0 {
		fmt.Println("Error: Masukan harus bilangan bulat positif.")
		return
	}

	result := pertemuan_2311102275(x, y)
	fmt.Printf("Keluaran: Jumlah pertemuan dalam setahun: %d\n", result)
}
