// Aby Hakim Al Yasiry Faozi 2311102208
package main

import (
	"fmt"
)

func hitungBiaya(menu2311102208, orang int, sisa bool) int {
	var biaya int
	if menu2311102208 <= 3 {
		biaya = 10000
	}
	return biaya
}

func main() {
	var M int
	fmt.Print("Masukkan banyaknya rombongan: ")
	fmt.Scan(&M)

	biayaRombongan := make([]int, M)

	fmt.Println("Total biaya untuk masing-masing rombongan:")
	for i, biaya := range biayaRombongan {
		fmt.Printf("Rombongan %d: Rp %d\n", i+1, biaya)
	}
}
