// Aby Hakim Al Yasiry Faozi 2311102208
package main

import "fmt"

func Hitungganjil(angka2311102208 []int) int {
	count := 0
	for _, angka := range angka2311102208 {
		if angka%2 != 0 {
			count++
		}
	}
	return count
}

func main() {
	angka2311102208 := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

	jumlahGanjil := Hitungganjil(angka2311102208)

	fmt.Println("Jumlah bilangan ganjil:", jumlahGanjil)
}
