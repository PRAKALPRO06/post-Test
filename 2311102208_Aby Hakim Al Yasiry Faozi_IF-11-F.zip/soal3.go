// Aby Hakim Al Yasiry Faozi 2311102208
package main

import (
	"fmt"
)

func cetakDeret(n2311102208 int) {
	for n2311102208 != 1 {
		fmt.Print(n2311102208, " ")
		if n2311102208%2 == 0 {
			n2311102208 /= 2
		} else {
			n2311102208 = 3*n2311102208 + 1
		}
	}
	fmt.Println(1)
}

func main() {
	var n2311102208 int
	fmt.Print("Masukkan: ")
	fmt.Scanln(&n2311102208)
	cetakDeret(n2311102208)
}
