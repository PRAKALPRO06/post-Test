package main

import (
	"fmt"
)

func identitas() {
	fmt.Println("=================================")
	fmt.Println("Nama: Haposan Siregar")
	fmt.Println("NIM: 2311102210")
	fmt.Println("=================================")
}


func main() {
	identitas() // Menampilkan  identitas
    
    var a, b int

    // Meminta input nilai untuk a dan b
    fmt.Print("Masukkan nilai a: ")
    fmt.Scan(&a)
    fmt.Print("Masukkan nilai b: ")
    fmt.Scan(&b)

    // Variabel untuk menghitung jumlah angka ganjil
    count := 0

    // Mencetak judul tabel
    fmt.Println("Bilangan Ganjil\t| Jumlah")

    // Melakukan iterasi dari a hingga b
    for i := a; i <= b; i++ {
        if i%2 != 0 { // Memeriksa apakah angka ganjil
            count++
            // Mencetak angka ganjil dan jumlah saat ini
            fmt.Printf("%d\t\t| %d\n", i, count)
        }
    }

    // Baris hasil akhir
    fmt.Printf("\nTotal banyaknya angka ganjil: %d\n", count)
}