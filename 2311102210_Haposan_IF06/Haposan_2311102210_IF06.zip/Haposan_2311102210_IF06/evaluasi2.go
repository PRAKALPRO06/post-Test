package main

import "fmt"

func identitas() {
	fmt.Println("=================================")
	fmt.Println("Nama: Haposan Siregar")
	fmt.Println("NIM: 2311102210")
	fmt.Println("=================================")
}


func main() {
	identitas() // Menampilkan identitas
    
	var jumlahRombongan int
	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scanln(&jumlahRombongan)

	for i := 1; i <= jumlahRombongan; i++ {
		var jumlahMenu, jumlahOrang, sisaMakanan int
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) untuk rombongan %d: ", i)
		fmt.Scanln(&jumlahMenu, &jumlahOrang, &sisaMakanan)

		var totalBiaya int
		if jumlahMenu <= 3 {
			totalBiaya = 10000
		} else {
			totalBiaya = 10000 + (jumlahMenu-3)*2500
		}

		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, totalBiaya)
	}
	
}