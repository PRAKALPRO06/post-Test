package main

import (
	"fmt"
)

// Fungsi rekursi untuk menjumlahkan kelipatan 4
func jumlahKelipatanEmpat() int {
	var angka int

	// Masukkan angka
	fmt.Scan(&angka)

	// Kasus dasar: jika angka negatif, hentikan rekursi
	if angka < 0 {
		return 0
	}

	// Periksa apakah angka kelipatan 4, jika ya, tambahkan ke jumlah
	if angka%4 == 0 {
		return angka + jumlahKelipatanEmpat()
	}

	// Jika bukan kelipatan 4, lanjutkan rekursi tanpa menambahkan
	return jumlahKelipatanEmpat()
}

func identitas() {
	fmt.Println("=================================")
	fmt.Println("Nama: Haposan Siregar")
	fmt.Println("NIM: 2311102210")
	fmt.Println("=================================")
}


func main() {
	identitas() // Menampilkan identitas
    
	fmt.Println("Masukkan bilangan (negatif untuk berhenti):")

	// Panggil fungsi rekursi dan simpan hasilnya
	jumlah := jumlahKelipatanEmpat()

	// Keluarkan hasilnya
	fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", jumlah)
}