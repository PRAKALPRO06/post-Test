package main

import (
	"fmt"
	"strconv"
)

//2311102260 Ariiq Radhitya Pradana

func main() {
	var input_2311102260 int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scan(&input_2311102260)

	inputStr := strconv.Itoa(input_2311102260)
	length := len(inputStr)

	tengah := length / 2
	var sisiKiri, sisiKanan int

	if length%2 != 0 {
		sisiKiri, _ = strconv.Atoi(inputStr[:tengah+1])
		sisiKanan, _ = strconv.Atoi(inputStr[tengah+1:])
	} else {
		sisiKiri, _ = strconv.Atoi(inputStr[:tengah])
		sisiKanan, _ = strconv.Atoi(inputStr[tengah:])
	}

	fmt.Printf("Bilangan 1: %d\n", sisiKiri)
	fmt.Printf("Bilangan 2: %d\n", sisiKanan)
	fmt.Printf("Hasil penjumlahan: %d\n", sisiKiri+sisiKanan)
}
