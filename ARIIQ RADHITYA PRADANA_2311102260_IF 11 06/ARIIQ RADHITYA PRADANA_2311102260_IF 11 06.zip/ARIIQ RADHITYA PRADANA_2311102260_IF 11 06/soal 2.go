package main

import (
	"fmt"
	"strconv"
)

//2311102260 Ariiq Radhitya Pradana

func hadiahPeserta_2311102260(nomorKartu int) string {
	kartuStr := strconv.Itoa(nomorKartu)
	digitSet := make(map[rune]bool)

	samaSemua := true
	berbedaSemua := true

	for i, digit := range kartuStr {
		if i > 0 && digit != rune(kartuStr[0]) {
			samaSemua = false
		}
		if digitSet[digit] {
			berbedaSemua = false
		}
		digitSet[digit] = true
	}

	if samaSemua {
		return "Hadiah A"
	} else if berbedaSemua {
		return "Hadiah B"
	}
	return "Hadiah C"
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&n)

	hadiahA, hadiahB, hadiahC := 0, 0, 0

	for i := 1; i <= n; i++ {
		var nomorKartu int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scan(&nomorKartu)

		hasilHadiah := hadiahPeserta_2311102260(nomorKartu)
		fmt.Println(hasilHadiah)

		switch hasilHadiah {
		case "Hadiah A":
			hadiahA++
		case "Hadiah B":
			hadiahB++
		case "Hadiah C":
			hadiahC++
		}
	}

	fmt.Printf("Jumlah yang memperoleh Hadiah A: %d\n", hadiahA)
	fmt.Printf("Jumlah yang memperoleh Hadiah B: %d\n", hadiahB)
	fmt.Printf("Jumlah yang memperoleh Hadiah C: %d\n", hadiahC)
}
