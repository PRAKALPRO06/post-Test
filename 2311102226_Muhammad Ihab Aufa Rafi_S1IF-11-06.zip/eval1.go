package main

import "fmt"

//muhammad ihab aufa rafi 2311102226

func menghitung_ganjil (a_226, b_226 int) int {
	hitung :=  0
	for i := a_226; i <= b_226; i++{
		if i % 2 != 0{
			hitung++
		}
	}
	return hitung
}

func main(){
	var a_226, b_226 int
	fmt.Printf("Masukkan nilai a: ")
	fmt.Scan(&a_226)
	fmt.Printf("Masukkan nilai b: ")
	fmt.Scan(&b_226)
	if a_226 <= b_226{
		menghitung_ganjil(a_226, b_226)
		fmt.Printf("Banyaknya bilangan ganjil: ")
		fmt.Println(menghitung_ganjil(a_226, b_226))
	}else{
		fmt.Printf("Masukan salah.")
	}
}