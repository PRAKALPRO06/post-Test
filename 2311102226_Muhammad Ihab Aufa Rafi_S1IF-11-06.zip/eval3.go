package main

import "fmt"

//Muhammad Ihab Aufa Rafi 2311102226

func sumKelipatan4Iteratif() int {
        var num_2311102226, sum int
		fmt.Print("Masukkan bilangan (negatif untuk berhenti): ")
        for {    
		fmt.Scan(&num_2311102226)
        	if num_2311102226 < 0 {
            	break
        	}
        	if num_2311102226%4 == 0 {
                sum += num_2311102226
        	}
        }
        return sum
}

func main() {
    sumKelipatan4Iteratif()
    fmt.Println("Jumlah bilangan kelipatan 4: ")
	fmt.Println(sumKelipatan4Iteratif())
}