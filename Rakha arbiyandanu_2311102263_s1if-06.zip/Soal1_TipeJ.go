package main
//Rakha Arbiyandanu_2311102263
import (
	"fmt"
	"math"
)

func main() {
	var masukan int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&masukan)

	length := int(math.Log10(float64(masukan))) + 1

	var batas int
	if length%2 == 0 {
		batas = int(math.Pow10(length / 2))
	} else {
		batas = int(math.Pow10((length / 2) + 1))
	}

	kiri_2311102263 := masukan / batas
	kanan := masukan % batas

	// Menampilkan hasil
	fmt.Println("Bilangan 1:", kiri_2311102263)
	fmt.Println("Bilangan 2:", kanan)
	fmt.Println("Hasil penjumlahan:", kiri_2311102263+kanan)
}
