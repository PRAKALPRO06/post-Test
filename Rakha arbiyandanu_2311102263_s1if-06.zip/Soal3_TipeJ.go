package main
//Rakha Arbiyandanu_2311102263
import "fmt"

func perkalian_2311102263(n, m int) int {
	if m == 0 {
		return 0
	}

	if m > 0 {
		return n + perkalian_2311102263(n, m-1)
	}
	return -perkalian_2311102263(n, -m)
}

func main() {
	var n, m int

	fmt.Print("Masukkan bilangan n: ")
	fmt.Scan(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scan(&m)

	hasil := perkalian_2311102263(n, m)

	fmt.Printf("Hasil dari %d x %d = %d\n", n, m, hasil)
}
