package main

import (
	"fmt"
)

func main() {
	var a, bil_2311102264 int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&bil_2311102264)
	countOdd := 0
	for i := a; i <= bil_2311102264; i++ {
		if i%2 != 0 {
			countOdd++
		}
	}
	fmt.Printf("Banyaknya angka ganjil: %d\n", countOdd)
}
