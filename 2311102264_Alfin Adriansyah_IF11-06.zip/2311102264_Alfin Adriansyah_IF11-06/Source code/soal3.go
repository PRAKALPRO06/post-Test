package main

import (
	"fmt"
)

func jumlahKelipatan4(angka []int, indeks int) int {
	if indeks == len(angka) {
		return 0
	}

	if angka[indeks] > 0 && angka[indeks]%4 == 0 {
		return angka[indeks] + jumlahKelipatan4(angka, indeks+1)
	}
	return jumlahKelipatan4(angka, indeks+1)
}

func main() {
	var angka []int
	var bil_2311102264 int

	fmt.Println("Masukkan bilangan (negatif untuk berhenti):")
	for {
		fmt.Scan(&bil_2311102264)
		if bil_2311102264 < 0 {
			break
		}
		angka = append(angka, bil_2311102264)
	}
	total := jumlahKelipatan4(angka, 0)
	fmt.Println("Jumlah bilangan kelipatan 4:", total)
}
