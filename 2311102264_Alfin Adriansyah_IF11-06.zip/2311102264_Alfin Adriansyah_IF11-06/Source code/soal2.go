package main

import "fmt"

func main() {
	var M int
	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&M)

	for i := 0; i < M; i++ {
		var jumlahMenu, jumlahOrang, sisa_2311102264 int
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) untuk rombongan %d: ", i+1)
		fmt.Scan(&jumlahMenu, &jumlahOrang, &sisa_2311102264)

		biaya := 10000
		if jumlahMenu > 3 {
			biaya += (jumlahMenu - 3) * 2500
		}
		if jumlahMenu > 50 {
			biaya = 100000
		}
		if sisa_2311102264 == 1 {
			biaya *= jumlahOrang
		}

		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i+1, biaya)
	}
}
