package main

import "fmt"

//Postest Rory RefALDO Sinulingga 2311102323
func main() {
	var jam_aldo, menit_aldo int
	var member_aldo bool
	var voucher_aldo int

	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scanln(&jam_aldo)
	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scanln(&menit_aldo)
	fmt.Print("Apakah member? (true/false): ")
	fmt.Scanln(&member_aldo)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scanln(&voucher_aldo)

// variabel tambahan saya adalah aldo       

	biaya_aldo := hitungBiaya(jam_aldo, menit_aldo, member_aldo, voucher_aldo)
	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", biaya_aldo)
}

func hitungBiaya(jam_aldo int, menit_aldo int, member_aldo bool, voucher_aldo int) float64 {
	var tarif float64
	if member_aldo {
		tarif = 3500
	} else {
		tarif = 5000
	}

	totalMenit := jam_aldo*60 + menit_aldo
	totalJam := totalMenit / 60
	if totalMenit%60 < 10 && totalJam > 1 {
		totalJam--
	}

	biaya_aldo := float64(totalJam) * tarif
	if voucher_aldo > 0 && totalJam > 3 {
		digitVoucher := len(fmt.Sprint(voucher_aldo))
		if digitVoucher == 5 || digitVoucher == 6 {
			biaya_aldo -= biaya_aldo * 0.1
		}
	}

	return biaya_aldo
}