package main

import (
	"fmt"
)

func isPerfectNumber(num_aldo int) bool {
	sum := 1
	for i := 2; i*i <= num_aldo; i++ {
		if num_aldo%i == 0 {
			sum += i
			if i*i != num_aldo {
				sum += num_aldo / i
			}
		}
	}
	return sum == num_aldo
}
// Rory Refaldo Sinulinggga 2311102323
func main() {
	var a_aldo, b_aldo int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scanln(&a_aldo)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scanln(&b_aldo)
//code tambahan aldo
	fmt.Printf("Perfect numbers antara %d dan %d: ", a_aldo, b_aldo)
	for i := a_aldo; i <= b_aldo; i++ {
		if isPerfectNumber(i) {
			fmt.Printf("%d ", i)
		}
	}
	fmt.Println()
}
