package main

import "fmt"

func main() {
        var xAldo, yAldo, countAldo int

        fmt.Print("Masukkan nilai xAldo: ")
        fmt.Scan(&xAldo)

        fmt.Print("Masukkan nilai yAldo: ")
        fmt.Scan(&yAldo)

        for iAldo := 1; iAldo <= 365; iAldo++ {
                if iAldo%xAldo == 0 && iAldo%yAldo != 0 {
                        countAldo++
                }
        }

        fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", countAldo)
}