package main

import "fmt"

func main() {
    var nim = 2311102026
    fmt.Println("NIM:", nim)

    var M int
   