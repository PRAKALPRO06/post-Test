package main

import (
	"fmt"
)

func perkalianRekursif(n, m, hasil int) int {
	if n == 0 {
		return hasil
	}
	return perkalianRekursif(n-1, m, hasil+m)
}

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scan(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scan(&m)

	hasilRekursif := perkalianRekursif(n, m, 0)
	fmt.Printf("Hasil dari %d x %d (rekursif): %d\n", n, m, hasilRekursif)
}
