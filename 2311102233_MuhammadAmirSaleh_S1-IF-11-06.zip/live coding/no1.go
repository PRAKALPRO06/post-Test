///Muhammad Amir Saleh(2311102233)

package main

import (
	"fmt"
	"strconv"
)

func main() {
	var input int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scan(&input)

	if input <= 10 {
		fmt.Println("Bilangan harus lebih besar dari 10.")
		return
	}

	inputStr := strconv.Itoa(input)
	panjang := len(inputStr)

	var tengah int
	if panjang%2 == 0 {
		tengah = panjang / 2
	} else {
		tengah = panjang/2 + 1
	}

	bilanganAmir := inputStr[:tengah]
	bilangan2311102233 := inputStr[tengah:]

	bilangan1Int, _ := strconv.Atoi(bilanganAmir)
	bilangan2Int, _ := strconv.Atoi(bilangan2311102233)

	fmt.Printf("Bilangan 1: %s\n", bilanganAmir)
	fmt.Printf("Bilangan 2: %s\n", bilangan2311102233)
	fmt.Printf("Hasil penjumlahan: %d\n", bilangan1Int+bilangan2Int)
}
