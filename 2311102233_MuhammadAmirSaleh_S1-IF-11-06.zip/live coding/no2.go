///Muhammad Amir Saleh(2311102233)

package main

import (
	"fmt"
)

func tentukanHadiah_2311102233(card string) string {
	digitCount := make(map[rune]int)

	for _, digit := range card {
		digitCount[digit]++
	}

	if len(digitCount) == 1 {
		return "Hadiah A"
	} else if len(digitCount) == len(card) {
		return "Hadiah B"
	}
	return "Hadiah C"
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&n)

	NomorKartu := make([]string, n)
	jumlahHadiah := map[string]int{"Hadiah A": 0, "Hadiah B": 0, "Hadiah C": 0}
	hadiahPeserta := make([]string, n)

	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i+1)
		fmt.Scan(&NomorKartu[i])
		s
		hadiah := tentukanHadiah(NomorKartu[i])
		hadiahPeserta[i] = hadiah
		jumlahHadiah[hadiah]++
	}

	for _, hadiah := range hadiahPeserta {
		fmt.Println(hadiah)
	}

	fmt.Printf("Jumlah yang memperoleh Hadiah A: %d\n", jumlahHadiah["Hadiah A"])
	fmt.Printf("Jumlah yang memperoleh Hadiah B: %d\n", jumlahHadiah["Hadiah B"])
	fmt.Printf("Jumlah yang memperoleh Hadiah C: %d\n", jumlahHadiah["Hadiah C"])
}
