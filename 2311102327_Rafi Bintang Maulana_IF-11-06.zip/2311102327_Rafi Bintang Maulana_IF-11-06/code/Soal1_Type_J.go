package main

import (
	"fmt"
	"strconv"
)

func main() {
	var input_2311102327 int
	fmt.Print("Masukan bilangan bulat positif (>10) : ")
	fmt.Scanln(&input_2311102327)

	inputString := strconv.Itoa(input_2311102327)
	digitLength := len(inputString)

	var tempatdiPotong int
	if digitLength%2 == 0 {
		tempatdiPotong = digitLength / 2
	} else {
		tempatdiPotong = (digitLength + 1) / 2
	}

	aString := inputString[:tempatdiPotong]
	bString := inputString[tempatdiPotong:]

	a, _ := strconv.Atoi(aString)
	b, _ := strconv.Atoi(bString)

	fmt.Println("Bilangan 1 :", a)
	fmt.Println("Bilangan 2 :", b)
	fmt.Println("Hasil Penjumlahan :", a+b)
}
