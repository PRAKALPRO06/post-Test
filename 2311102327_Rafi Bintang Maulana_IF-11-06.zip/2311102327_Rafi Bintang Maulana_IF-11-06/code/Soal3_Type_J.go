package main

import "fmt"

func ProsedurPerkalian(n_2311102327, Bilangan_m int) int {
	if Bilangan_m == 0 {
		return 0
	}
	return n_2311102327 + ProsedurPerkalian(n_2311102327, Bilangan_m-1)
}

func main() {
	var n_2311102327, Bilangan_m int

	fmt.Print("Masukan bilangan n: ")
	fmt.Scanln(&n_2311102327)

	fmt.Print("Masukan bilangan m: ")
	fmt.Scanln(&Bilangan_m)

	hasil := ProsedurPerkalian(n_2311102327, Bilangan_m)

	fmt.Printf("Hasil dari %d x %d = %d\n", n_2311102327, Bilangan_m, hasil)
}
