package main

import (
	"fmt"
)

func main() {
	var jumlahPeserta_2311102327 int
	fmt.Print("Masukan Jumlah Peserta : ")
	fmt.Scanln(&jumlahPeserta_2311102327)

	DapetHadiahA, DapetHadiahB, DapetHadiahC := 0, 0, 0

	for i := 1; i <= jumlahPeserta_2311102327; i++ {
		var nomorKartu string
		fmt.Printf("Masukan nomor kartu peserta ke-%d : ", i)
		fmt.Scanln(&nomorKartu)

		jenisHadiah := HadiahNyaApa(nomorKartu)
		fmt.Println(jenisHadiah)

		switch jenisHadiah {
		case "Hadiah A":
			DapetHadiahA++
		case "Hadiah B":
			DapetHadiahB++
		case "Hadiah C":
			DapetHadiahC++
		}
	}

	fmt.Println("\nJumlah yang diperoleh Hadiah A :", DapetHadiahA)
	fmt.Println("Jumlah yang diperoleh Hadiah B :", DapetHadiahB)
	fmt.Println("Jumlah yang diperoleh Hadiah C :", DapetHadiahC)
}

func HadiahNyaApa(NomerKartuNya string) string {
	samaSemua := true
	for i := 1; i < len(NomerKartuNya); i++ {
		if NomerKartuNya[i] != NomerKartuNya[0] {
			samaSemua = false
			break
		}
	}
	if samaSemua {
		return "Hadiah A"
	}

	bedaSemua := true
	for i := 0; i < len(NomerKartuNya)-1; i++ {
		for j := i + 1; j < len(NomerKartuNya); j++ {
			if NomerKartuNya[i] == NomerKartuNya[j] {
				bedaSemua = false
				break
			}
		}
	}
	if bedaSemua {
		return "Hadiah B"
	}

	return "Hadiah C"
}
