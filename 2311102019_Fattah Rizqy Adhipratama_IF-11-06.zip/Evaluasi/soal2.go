// 2311102019 FATTAH RIZQY ADHIPRATAMA IF-11-06
package main

import "fmt"

func isPerfectNumber(n int) bool {
	sum_2311102019 := 1
	for i := 2; i*i <= n; i++ {
		if n%i == 0 {
			sum_2311102019 += i
			if i*i != n {
				sum_2311102019 += n / i
			}
		}
	}
	return sum_2311102019 == n
}

func findPerfectNumbers(a, b int) []int {
	var perfectNumbers []int
	for i := a; i <= b; i++ {
		if isPerfectNumber(i) {
			perfectNumbers = append(perfectNumbers, i)
		}
	}
	return perfectNumbers
}

func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scanln(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scanln(&b)

	perfectNumbers := findPerfectNumbers(a, b)
	fmt.Printf("Perfect numbers antara %d dan %d: ", a, b)
	for i, num := range perfectNumbers {
		if i > 0 {
			fmt.Print(", ")
		}
		fmt.Print(num)
	}
	fmt.Println()
}