// 2311102019 FATTAH RIZQY ADHIPRATAMA IF-11-06
package main

import "fmt"

func main (){
	var x_2311102019, y int
	fmt.Print("Masukkan Nilai x : ")
	fmt.Scan(&x_2311102019)
	fmt.Print("Masukkan Nilai y : ")
	fmt.Scan(&y)
	count := 0
	for i := 1; i <= 365; i++{
		if i%x_2311102019 == 0 && i%y != 0 {
			count++
		}
	}
	fmt.Printf("Jumlah pertemuan dalam setahun : %d\n", count)
}