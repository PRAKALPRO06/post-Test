// 2311102019 FATTAH RIZQY ADHIPRATAMA IF-11-06
package main

import "fmt"

func hitungBiayaSewa(jam int, menit int, member_2311102019 bool, voucher int) int {
	tarifMember := 3500
	tarifNonMember := 5000

	durasiTotal := jam
	if menit >= 10 {
		durasiTotal += 1
	}

	tarif := 0
	if member_2311102019 {
		tarif = tarifMember * durasiTotal
	} else {
		tarif = tarifNonMember * durasiTotal
	}

	if durasiTotal > 3 {
		Digit := voucher % 10
		if Digit == 5 || Digit == 6 {
			tarif = tarif - (tarif / 10) 
		}
	}
	return tarif
}

func main() {
	var jam, menit, voucher int
	var member_2311102019 bool
	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah member ? (true/false): ")
	fmt.Scan(&member_2311102019)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&voucher)
	biayaSewa := hitungBiayaSewa(jam, menit, member_2311102019, voucher)
	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %d\n", biayaSewa)
} 