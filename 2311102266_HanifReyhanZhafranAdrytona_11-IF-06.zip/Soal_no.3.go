// 2311102266_Hanif reyhan zharan adrytona

package main

import (
	"fmt"
)

func kali_2311102266(n, m int) int {
	
	if m == 0 {
		return 0
	}

	return n + kali_2311102266(n, m-1)
}

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scan(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scan(&m)

	hasil := kali_2311102266(n, m)
	fmt.Printf("Hasil dari %d x %d = %d\n", n, m, hasil)
}
