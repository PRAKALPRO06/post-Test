// 2311102266_Hanif Reyhan Zhafran Arytona

package main

import (
	"fmt"
)

func main() {
	var Nomor, div, Kiri_2311102266, Kanan_2311102266 int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&Nomor)

	temp := Nomor
	JumlahAngka := 0
	for temp > 0 {
		JumlahAngka++
		temp /= 10
	}

	mid := (JumlahAngka + 1) / 2
	div = 1
	for i := 0; i < JumlahAngka-mid; i++ {
		div *= 10
	}

	Kiri_2311102266 = Nomor / div
	Kanan_2311102266 = Nomor % div

	fmt.Println("Bilangan 1:", Kiri_2311102266)
	fmt.Println("Bilangan 2:", Kanan_2311102266)
	fmt.Println("Hasil penjumlahan:", Kiri_2311102266+Kanan_2311102266)
}
