// 2311102266_Hanif Reyhan Zhafran Arytona
package main

import (
	"fmt"
)

func main() {
	var JMLH_2311102266 int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&JMLH_2311102266)

	hadiahA, hadiahB, hadiahC := 0, 0, 0

	for i := 1; i <= JMLH_2311102266; i++ {
		var nomorKartu int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scan(&nomorKartu)

		if Angka_Sama(nomorKartu) {
			fmt.Println("Hadiah A")
			hadiahA++
		} else if Angka_Beda(nomorKartu) {
			fmt.Println("Hadiah B")
			hadiahB++
		} else {
			fmt.Println("Hadiah C")
			hadiahC++
		}
	}

	fmt.Printf("Jumlah yang dapet Hadiah A: %d\n", hadiahA)
	fmt.Printf("Jumlah yang dapet Hadiah B: %d\n", hadiahB)
	fmt.Printf("Jumlah yang dapet Hadiah C: %d\n", hadiahC)
}

func Angka_Sama(n int) bool {
	digitAwal := n % 10
	for n > 0 {
		if n%10 != digitAwal {
			return false
		}
		n /= 10
	}
	return true
}

func Angka_Beda(n int) bool {
	digitMap := make(map[int]bool)
	for n > 0 {
		digit := n % 10
		if digitMap[digit] {
			return false
		}
		digitMap[digit] = true
		n /= 10
	}
	return true
}
