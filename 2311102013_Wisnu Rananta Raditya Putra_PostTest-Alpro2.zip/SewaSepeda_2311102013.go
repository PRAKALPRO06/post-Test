//Wisnu Rananta Raditya Putra / 2311102013 / IF-11-06

package main
import "fmt"

func hitungSewa(jam, menit int, isMember bool, voucher string) float64 {
        tarifMember_2311102013 := 3500
        tarifNonMember := 5000

        durasiJam := jam
        if menit >= 10 && jam >= 1 {
                durasiJam++
        }

        tarif := tarifMember_2311102013
        if !isMember {
                tarif = tarifNonMember
        }

        biayaSewa := float64(durasiJam) * float64(tarif)

        if len(voucher) >= 5 && durasiJam > 3 {
                biayaSewa *= 0.9
        }

        return biayaSewa
}

func main() {
    var jam, menit int
    var isMember bool
    var voucher string

    fmt.Print("Masukkan durasi (jam): ")
    fmt.Scan(&jam)

    fmt.Print("Masukkan durasi (menit): ")
    fmt.Scan(&menit)

    fmt.Print("Apakah member? (true/false): ")
    fmt.Scan(&isMember)

    fmt.Print("Masukkan nomor voucher (jika ada): ")
    fmt.Scan(&voucher)

    biayaAkhir := hitungSewa(jam, menit, isMember, voucher)
    fmt.Printf("Biaya sewa setelah diskon (jika ada): Rp %.2f\n", biayaAkhir)
}
