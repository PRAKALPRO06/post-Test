//Wisnu Rananta Raditya Putra / 2311102013 / IF-11-A

package main
import "fmt"

func main(){
   var n_2311102013 int

   fmt.Print("Masukkan bilangan: ")
   fmt.Scanf("%d", &n_2311102013)

   sum1 := 0
   for i:=1; i<n_2311102013;i++{
      if n_2311102013 % i ==0{
         sum1 += i
      }
   }
   
   if sum1 == n_2311102013 {
      print("Bilangan ini termasuk perfecrt number")
   }else{
      print("BIlangan ini tidak termasuk perfect number")
   }
}