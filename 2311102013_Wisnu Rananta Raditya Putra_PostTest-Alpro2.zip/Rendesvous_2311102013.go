//Wisnu Rananta Raditya Putra / 2311102013  / IF-11-06

package main
import "fmt"

func main() {
        var x_2311102013, y int

        fmt.Print("Masukkan x: ")
        fmt.Scan(&x_2311102013)

        fmt.Print("Masukkan y: ")
        fmt.Scan(&y)

        jumlahPertemuan := hitungPertemuan(x_2311102013, y)
        fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", jumlahPertemuan)
}

func hitungPertemuan(x, y int) int {
        jumlah := 0
        for i := 1; i <= 365; i++ {
                if i%x == 0 && i%y != 0 {
                        jumlah++
                }
        }
        return jumlah
}