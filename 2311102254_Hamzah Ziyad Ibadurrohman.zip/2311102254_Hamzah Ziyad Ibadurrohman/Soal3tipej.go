package main

import "fmt"

//2311102254
func main() {
	var n2311102254, m int
	var hasil int
	fmt.Print("Masukkan bilangan N :")
	fmt.Scan(&n2311102254)
	fmt.Print("Masukkan bilangan M :")
	fmt.Scan(&m)
	hasil = n2311102254 * m
	fmt.Print("Hasil dari ", n2311102254, " x ", m, " : ", hasil)

}
