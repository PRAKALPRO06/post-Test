package main

import "fmt"

func kasihhadiah(Peserta int) int {
	var nomor2311102254 int
	for i := 1; i <= Peserta; i++ {
		fmt.Print("masukkan nomor kartu peserta ke-", i, ": ")
		fmt.Scan(&nomor2311102254)
		if nomor2311102254/nomor2311102254 == 0 {
			fmt.Println("Hadiah A")
			fmt.Print("Jumlah hadiah a: ", nomor2311102254)
		} else if nomor2311102254 == nomor2311102254+1 {
			fmt.Println("Hadiah B")
			fmt.Print("Jumlah hadiah b: ", nomor2311102254)
		} else {
			fmt.Println("Hadiah C")
			fmt.Print("Jumlah hadiah c: ", nomor2311102254)
		}
	}
	return nomor2311102254

}

func main() {
	var Peserta int

	fmt.Print("masukkan jumlah Peserta: ")
	fmt.Scan(&Peserta)

	fmt.Print(kasihhadiah(Peserta))

}
