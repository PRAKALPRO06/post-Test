package main

import "fmt"

//2311102254
func main() {
	var a2311102254, b2 int
	fmt.Print("bilangan 1: ")
	fmt.Scanln(&a2311102254)
	fmt.Print("bilangan 2: ")
	fmt.Scanln(&b2)
	if a2311102254 && b2 >= 10 {
		var hasil int
		hasil = a2311102254 + b2
		fmt.Print("hasil penjumlahan :", hasil)
	} else {
		fmt.Println("Bilangan positif harus >10.")
	}

}
