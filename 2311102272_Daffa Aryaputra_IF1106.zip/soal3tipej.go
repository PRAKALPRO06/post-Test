package main

import "fmt"

func perkalian(n, m int) int {
	if n == 0 {
		return 0
	}
	return m + perkalian(n-1, m)
}

func main() {
	var var2311102272 int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scanln(&var2311102272)
	fmt.Print("Masukkan bilangan m: ")
	var var2311102272M int
	fmt.Scanln(&var2311102272M)

	hasil := perkalian(var2311102272, var2311102272M)

	fmt.Printf("Hasil dari %d x %d = %d\n", var2311102272, var2311102272M, hasil)
}
