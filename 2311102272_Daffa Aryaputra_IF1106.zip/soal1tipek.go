package main

import (
	"fmt"
)

func cekHadiah(nomorKartu int) string {
	digitPertama := nomorKartu % 10

	sama := true
	berbeda := true
	digitMap := make(map[int]bool)

	for nomorKartu > 0 {
		digit := nomorKartu % 10

		if digit != digitPertama {
			sama = false
		}

		if digitMap[digit] {
			berbeda = false
		}
		digitMap[digit] = true

		nomorKartu /= 10
	}

	if sama {
		return "Hadiah A"
	} else if berbeda {
		return "Hadiah B"
	} else {
		return "Hadiah C"
	}
}

func main() {
	var jumlahPeserta int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scanln(&jumlahPeserta)

	var hadiahA, hadiahB, hadiahC int

	for i := 1; i <= jumlahPeserta; i++ {
		var _2311102272 int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scanln(&_2311102272)

		hadiah := cekHadiah(_2311102272)
		fmt.Println(hadiah)

		switch hadiah {
		case "Hadiah A":
			hadiahA++
		case "Hadiah B":
			hadiahB++
		default:
			hadiahC++
		}
	}

	fmt.Println("Jumlah yang memperoleh Hadiah A:", hadiahA)
	fmt.Println("Jumlah yang memperoleh Hadiah B:", hadiahB)
	fmt.Println("Jumlah yang memperoleh Hadiah C:", hadiahC)
}
