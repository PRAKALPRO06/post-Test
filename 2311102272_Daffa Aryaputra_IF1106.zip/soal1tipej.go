package main

import (
	"fmt"
	"math"
)

func main() {

	var number int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&number)

	numberLength := int(math.Log10(float64(number))) + 1

	var part1, part2 int

	if numberLength%2 == 0 {
		power := numberLength / 2
		divisor := int(math.Pow(10, float64(power)))
		part1 = number / divisor
		part2 = number % divisor
	} else {
		power := (numberLength / 2) + 1
		divisor := int(math.Pow(10, float64(power)))
		part1 = number / divisor
		part2 = number % divisor
	}

	result := part1 + part2

	fmt.Println("Bilangan 1:", part1)
	fmt.Println("Bilangan 2:", part2)
	fmt.Println("Hasil penjumlahan:", result)
}
