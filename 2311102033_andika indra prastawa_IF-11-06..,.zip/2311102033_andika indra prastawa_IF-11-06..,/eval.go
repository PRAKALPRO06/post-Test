// 2311102033
package main

import (
	"fmt"
	"strconv"
)

func main() {
	var input_2311102033 int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scan(&input_2311102033)

	inputStr := strconv.Itoa(input_2311102033)
	panjang := len(inputStr)

	var bagian1, bagian2 string

	if panjang%2 != 0 {
		bagian1 = inputStr[:panjang/2+1]
		bagian2 = inputStr[panjang/2+1:]
	} else {
		bagian1 = inputStr[:panjang/2]
		bagian2 = inputStr[panjang/2:]
	}

	bil1, _ := strconv.Atoi(bagian1)
	bil2, _ := strconv.Atoi(bagian2)

	fmt.Println("Bilangan 1:", bil1)
	fmt.Println("Bilangan 2:", bil2)
	fmt.Println("Hasil penjumlahan:", bil1+bil2)
}
