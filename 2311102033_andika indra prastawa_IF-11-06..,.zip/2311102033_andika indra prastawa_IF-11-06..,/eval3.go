// 2311102033
package main

import (
	"fmt"
)

func menghitung_2311102033(n, m int) int {

	if m == 0 {
		return 0
	}

	if m < 0 {
		return -menghitung_2311102033(n, -m)
	}

	return n + menghitung_2311102033(n, m-1)
}
func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scan(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scan(&m)

	hasil := menghitung_2311102033(n, m)
	fmt.Printf("Hasil adalah %d x %d = %d\n", n, m, hasil)
}
