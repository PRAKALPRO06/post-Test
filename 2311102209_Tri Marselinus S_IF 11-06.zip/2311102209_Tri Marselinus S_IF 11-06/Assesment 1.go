package main

import "fmt"

// Nama : Tri Marselinus Sitanggang
// NIM : 2311102209
 

func main() {

	var bilangan2311102209 int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scan(&bilangan2311102209)


	panjang:= 0
	temp := bilangan2311102209
	for temp > 0 {
		panjang++
		temp /= 10
	}

	n := 1
	for i := 0; i < panjang/2; i++ {
		n*= 10
	}

	var kiri, kanan int
	if panjang%2 == 0 {
		kiri= bilangan2311102209 / n
		kanan = bilangan2311102209 % n
	} else {
		kiri= bilangan2311102209 / (n * 10)
		kanan = bilangan2311102209 % (n * 10)
	}


	fmt.Println("Bilangan 1 :",kiri)
	fmt.Println("Bilangan 2 :", kanan)
	fmt.Println("Hasil penjumlahan:",kiri + kanan)
}
