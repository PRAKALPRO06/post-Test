package main

import (
	"fmt"
)

func penjumlahan(n int, m int) int {

	if m == 0 {
		return 0
	}

	return n + penjumlahan(n, m-1)
}

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n dan m: ")
	fmt.Scan(&n, &m)

	hasil := penjumlahan(n, m)
	fmt.Println("Hasil:", hasil)
}
