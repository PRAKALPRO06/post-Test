package main 

import "fmt"

// Nama : Tri Marselinus S
// NIM : 2311102209


func main(){
	fmt.Print("Masukkan jumlah peserta:")
	fmt.Scan(%peserta)

	
	
}