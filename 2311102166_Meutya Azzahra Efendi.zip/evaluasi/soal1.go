// Meutya Azzahra Efendi
// 2311102166
// IF1106
package main

import (
	"fmt"
)

func main() {
	var input int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&input)

	if input <= 10 {
		fmt.Println("Input harus lebih besar dari 10.")
		return
	}

	// Menghitung panjang digit
	digitLength := 0
	for input > 0 {
		input /= 10
		digitLength++
	}

	// Menampilkan hasil
	fmt.Println("Bilangan 1:" )
	fmt.Println("Bilangan 2:" )
	fmt.Println("Hasil penjumlahan:")
}