// Meutya Azzahra Efendi
// 2311102166
// IF1106
package main

import "fmt"

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scanln(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scanln(&m)

	hasil := perkalianRekursif_66(n, m, 0)
	fmt.Printf("Hasil dari %d x %d = %d\n", n, m, hasil)
}

func perkalianRekursif_66(n, m, sum int) int {
	if m == 0 {
		return sum
	}
	return perkalianRekursif_66(n,m-1,sum+n)
}