// Meutya Azzahra Efendi
// 2311102166
// IF1106
package main

import (
	"fmt"
)

func main() {
	var n int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scanln(&n)

	var hadiahA, hadiahB, hadiahC int
	for i := 1; i <= n; i++ {
		var nomorKartu string
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scanln(&nomorKartu)

		jenisHadiah := tentukanJenisHadiah_66(nomorKartu)
		fmt.Println(jenisHadiah)

		switch jenisHadiah {
		case "Hadiah A":
			hadiahA++
		case "Hadiah B":
			hadiahB++
		case "Hadiah C":
			hadiahC++
		}
	}

	fmt.Println("Jumlah yang memperoleh Hadiah A:", hadiahA)
	fmt.Println("Jumlah yang memperoleh Hadiah B:", hadiahB)
	fmt.Println("Jumlah yang memperoleh Hadiah C:", hadiahC)
}

func tentukanJenisHadiah_66(nomorKartu string) string {
	var digitPertama string = string(nomorKartu[0])
	var semuaSama bool = true
	var semuaBerbeda bool = true

	for i := 1; i < len(nomorKartu); i++ {
		if string(nomorKartu[i]) != digitPertama {
			semuaSama = false
		}
		if string(nomorKartu[i]) == digitPertama {
			semuaBerbeda = false
		}
	}

	if semuaSama {
		return "Hadiah A"
	} else if semuaBerbeda {
		return "Hadiah B"
	} else {
		return"Hadiah C"
	}
}
